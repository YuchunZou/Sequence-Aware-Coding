#!/bin/bash
read -p "please iput: the iteration times code(static/stochastic) epsilon--" ts code epsilon
mycount=0
while [ $mycount -lt $ts ]
do
  #mpirun -np 21 python3 sac.py 10 4 $epsilon 4000 4000 4000 $code 0.2 
  mpirun -np 21 python3 sacc.py 10 4 $epsilon 4000 4000 4000 $code 0.2
  mycount=$[ $mycount + 1 ]
 done

