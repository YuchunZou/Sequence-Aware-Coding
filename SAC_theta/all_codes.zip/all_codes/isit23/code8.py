# first  third
from fig1 import occurance
from fig1 import strict_c_occurance
from fig1 import strict_u_occurance
from fig1 import strict_occurance

import numpy as np

from code2 import distribution

def generator8(n, u, c, ep):
    D = distribution(n, u, c)
    G = np.zeros(((u + c) * n, u * n))
    for i in range(u * n):
        G[i, i] = 1

    N = np.ceil(u * n * ep)
    for j in range(c):
        for m in range(n):
            # N = np.random.binomial(x * n, ep)
            placement = [0 for i in range(u)]
            l = 0
            while l < N:
                p = np.random.rand()
                for i in range(u):
                    if p < D[(i + 1, j + 1)]:
                        if D[(i + 1, j + 1)] == 1:
                            i = np.random.randint(i, u)
                        break
                for i_ in range(i + 1):
                    if placement[i_] < n:
                        placement[i_] += 1
                        l += 1
                        # if l >= N:
                            # break
            for i in range(u):
                choices = np.random.choice(n, placement[i], replace=False)
                for l in choices:
                    G[u * n + j * n + m, (u - 1 - i) * n + l] = np.random.rand()
    # print(np.count_nonzero(G))
    return G

def test_failure_random8(G, n, u, c, ep, times):
    P = [0 for i in range(n)]
    def pattern(n, sum):
        if n == 1:
            if sum <= u and sum >= -1 * c:
                P[0] = sum
                return True
            else:
                return False
        if sum <= u * n and sum >= -1 * c * n:
            while True: 
                P[n - 1] = np.random.randint(-1 * c, u + 1)
                if pattern(n - 1, sum - P[n - 1]) == True:
                    break
            return True
        else:
            return False
    
    def pattern_to_rows(P):
        ret = []
        for i in range(n):
            for j in range(u - P[i]):
                ret.append(j * n + i)
        return ret
    
    ret = [0, 0]
    for i in range(times):
        pattern(n, 0)
        ind = pattern_to_rows(P)
        Gd = G[np.ix_(ind, list(range(0, u * n)))]
        # up = max(P)
        # lo = min(P) * (-1)
        if np.linalg.matrix_rank(Gd) == u * n:
            ret[0] += 1
        ret[1] += 1
    return ret[0] / float(ret[1])

def code8(n, u, c, ep, times):
    ret = 10
    G = None
    for i in range(times):
        G0 = generator8(n, u, c, ep)
        test = test_failure_random8(G0, n, u, c, ep, 1000) 
        if test  >= ep:
            if test < ret:
                ret = test
                G = G0
    if G is None:
        return [None, None]
    else:
        return [ret, G]


def test8():
    u = 4
    c = 3
    n = 4

    # ep = .2
    times = 1000

    ret = []
    step = 100
    ep = 0
    for i in range(0, step + 1):
        ep = i / step
        # test1 = test_failure8(n, u, c, ep, times)
        r, G = code8(n, u, c, ep, times)
        test2 = test_failure_random8(G, n, u, c, ep, 10000)
        # if test < ep:
        #     print(ep, test)
        ret.append([ep, test2])
        ep += step
        print(i, "/", step, "\t", r, "\t", test2)
    # print(ret)
    return ret

if __name__ == "__main__":
    test8()
