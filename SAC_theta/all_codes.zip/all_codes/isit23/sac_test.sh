#!/bin/bash


#echo "please input the iteration times:"
#read times 
tablesize=`mpirun -np 6 python3 sac_1.py 4 3 0.25 200 200 200 stochastic 0`
array=(${tablesize//,/ })   
#t_com=((${array[0]}))
#t_dec=((${array[1]}))
echo ${array[0]}
echo ${array[1]}
a=${array[0]}""
b=${array[1]}""
c=$(bc <<< "($a + $b)/2")
echo $c
#val=`expr a + b`
#echo $((a + b))
#echo ${array[1]} | bc -l
#for var in ${array[@]}
#echo ${array[0]}""
#do
 #  echo $var
#done 
#echo ${{tablesize}}
#echo ${tablesize[1]}
