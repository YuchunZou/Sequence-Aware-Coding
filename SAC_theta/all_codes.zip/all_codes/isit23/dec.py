import time
import sys
import numpy as np
import ast

if __name__ == "__main__":
    code = sys.argv[1]
    D = [int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])]
    n = int(sys.argv[5]) 
    u = int(sys.argv[6]) 
    c = int(sys.argv[7]) 
    ep = float(sys.argv[8])
    P = [int(x) for x in sys.argv[9:]]

    index = []
    for i in range(n):
        for j in range(P[i]):
            index.append(j * n + i)
    print(index)
    print(len(list(filter(lambda x: x > u * n, index))))

    # with open('dec.txt') as f:
    #     lines = f.readlines()
    # data = [ast.literal_eval(line) for line in lines]

    if code == "static":
        from code1 import distribution
        from code1m import generator1m 
        Dist = distribution(n, u, c)
        G, _ = generator1m(n, u, c, ep, Dist)
    if code == "stochastic":
        from code1 import distribution
        from code7m import code7m
        Dist = distribution(n, u, c)
        times = 100
        _, G, _ = code7m(n, u, c, ep, times, Dist)

    elapsed_time = []
    # print(D)
    M = np.random.rand((u + c) * n, int(D[0] / n) * int(D[2] / u))
    print(M.size)
    # M = np.zeros(((u + c) * n, int(D[0] / n) * int(D[2] / u)))
    start = time.time()
    from scipy.sparse import csr_matrix
    from scipy.sparse.linalg import inv
    G0 = csr_matrix(G[np.ix_(index, list(range(0, u * n)))])
    G0 = inv(G0)
    # print(G0)
    M0 = M[np.ix_(index, list(range(0, u * n)))]
    # from scipy.sparse.linalg import spsolve
    # x = spsolve(G0, M0)
    x = G0.dot(M0)
    end = time.time()
    elapsed_time.append(end - start)
    # print(elapsed_time[-1])
    print(np.mean(elapsed_time))