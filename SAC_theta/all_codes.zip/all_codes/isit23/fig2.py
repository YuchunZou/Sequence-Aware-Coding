import csv

I = []
R = []
C = []

with open('fig2.txt', newline = '') as data:
    D = csv.reader(data, delimiter='\t')
    for l in D:
        x = l[0].split()
        I.append(float(x[0]) / float(x[2]))
        R.append(float(x[-2]))
        C.append(float(x[-1]))
print(I)
print(R)
print(C)

import numpy as np
print(np.mean([np.abs(I[i] - R[i]) for i in range(len(I))]))
print(np.mean([np.abs(I[i] * 20 - C[i]) for i in range(len(I))]))

import matplotlib.pyplot as plt
import matplotlib
import numpy as np

plt.style.use('default')
font = {'family' : 'Helvetica', 'weight' : 'normal', 'size'   : 16, }
lines = {'linewidth' : 2, 'color' : 'black'}
axes = {'edgecolor' : 'black', 'grid' : False, 'titlesize' : 'medium'}
grid = {'alpha' : 0.1, 'color' : 'black'}
figure = {'titlesize' : 32, 'autolayout' : True, 'figsize' : "4, 12"}

matplotlib.rc('font', **font)
matplotlib.rc('lines', **lines)
matplotlib.rc('axes', **axes)
matplotlib.rc('grid', **grid)
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['text.usetex'] = True

COLOR2 = "#69b3a2"
COLOR1 = "#3399e6"

fig, ax1 = plt.subplots()
fig.set_size_inches(4, 3)
ax1.plot(I, R, color=COLOR1, label="recoverability")
ax1.plot(I, I, '--', color='gray', alpha=0.4)
ax1.set_xlim([0, 1])
ax1.set_ylim([0, 1])
ax1.set_ylabel("actual recoverability", color=COLOR1)
ax1.set_yticks([0, 0.25, 0.5, 0.75, 1])
ax1.set_xticks([0, 0.25, 0.5, 0.75, 1])
ax1.tick_params(axis="y", labelcolor=COLOR1)
ax1.set_xlabel(r"$\theta$")
ax2 = ax1.twinx()
l2 = ax2.plot(I, C, label="complexity", color=COLOR2)
ax2.tick_params(axis="y", labelcolor=COLOR2)
ax2.set_ylabel("average complexity", color=COLOR2)
ax2.set_ylim([0, 20])
ax2.set_xticks([0, 0.25, 0.5, 0.75, 1])
ax1.grid("on")
ax2.grid("on")

# from mpl_toolkits.axes_grid1.inset_locator import inset_axes
# from mpl_toolkits.axes_grid1.inset_locator import mark_inset

# axins = inset_axes(ax1, 1, 1, loc='lower right')
# axins.plot(I, R, color=COLOR1, label="recoverability")
# axins.plot(I, I, '--', color='gray', alpha=0.4)
# axins.set_xlim(0.4, 0.5)
# axins.set_ylim(0.4, 0.5)
# axins.tick_params(axis='x', which='both', bottom=False, labelbottom=False)
# axins.tick_params(axis='y', which='both', left=False, labelleft=False)
# mark_inset(ax1, axins, loc1=1, loc2=3, fc="none", ec="0.5")

plt.tight_layout(pad=0.1)
# plt.show()
plt.savefig('./fig2.pdf', format='pdf', facecolor="white")



