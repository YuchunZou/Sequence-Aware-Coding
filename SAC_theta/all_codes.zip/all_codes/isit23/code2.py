# first

from fig1 import occurance
from fig1 import strict_c_occurance
from fig1 import strict_u_occurance
from fig1 import strict_occurance

import numpy as np

def distribution(n, u, c):
    ret = {}
    for j in range(1, c + 1):
        if j == 1:
            total = occurance(n, u, j)
        total = occurance(n, u, c) - occurance(n, u, j - 1)
        for i in range(1, u + 1):
            ret[(i, j)] = (occurance(n, i, c) - occurance(n, i, j - 1)) / total
    return ret

def code2(n, x, y, ep):
    D = distribution(n, x, y)
    ret = [0 for i in range(y)]
    for j in range(y):
        for i in range(x):
            if D[(i + 1,  j + 1)] >= ep:
                ret[j] = list(range(1, i + 2))
                break
    return ret


def generator2(n, u, c, ep):
    C = code2(n, u, c, ep)
    G = np.zeros(((u + c) * n, u * n))
    for i in range(u * n):
        G[i, i] = 1
    for j in range(c):
        for m in range(n):
            coeffients = np.random.rand(len(C[j]) * n)
            t = 0
            for i in C[j]:
                for l in range(n):
                    G[u * n + j * n + m, (u - i) * n + l] = coeffients[t]
                    t += 1
    # print(np.count_nonzero(G))
    return G, sum([len(x) for x in C])

def test_failure2(n, u, c, ep):
    G, _ = generator2(n, u, c, ep)

    P = [0 for i in range(n)]
    numbers = range(1, u + c + 1) 
    length = n 
    target = u * n

    import itertools
    iterable = itertools.product(numbers, repeat = length)
    predicate = lambda x: (sum(x) == target)
    vals = filter(predicate, iterable)

    def pattern_to_rows(P):
        ret = []
        for i in range(n):
            for j in range(P[i]):
                ret.append(j * n + i)
        return ret

    ret = [0, 0]
    for P in vals:
        ind = pattern_to_rows(P)
        Gd = G[np.ix_(ind, list(range(0, u * n)))]
        # up = max(P)
        # lo = min(P) * (-1)
        # return np.linalg.matrix_rank(Gd) == x * n, sum([np.abs(x) for x in P]) / 2, max(P), min(P) * (-1)
        if np.linalg.matrix_rank(Gd) == u * n:
            ret[0] += 1
        #     print(P, 1)
        # else:
        #     print(P, 0)
        ret[1] += 1
    return ret[0] / float(ret[1])

def test_failure_random2(n, u, c, ep, times):
    G, C = generator2(n, u, c, ep)

    P = [0 for i in range(n)]
    def pattern(n, sum):
        if n == 1:
            if sum <= u and sum >= -1 * c:
                P[0] = sum
                return True
            else:
                return False
        if sum <= u * n and sum >= -1 * c * n:
            while True: 
                P[n - 1] = np.random.randint(-1 * c, u + 1)
                if pattern(n - 1, sum - P[n - 1]) == True:
                    break
            return True
        else:
            return False
    
    def pattern_to_rows(P):
        ret = []
        for i in range(n):
            for j in range(u - P[i]):
                ret.append(j * n + i)
        return ret
    
    ret = [0, 0]
    for i in range(times):
        pattern(n, 0)
        ind = pattern_to_rows(P)
        Gd = G[np.ix_(ind, list(range(0, u * n)))]
        # up = max(P)
        # lo = min(P) * (-1)
        if np.linalg.matrix_rank(Gd) == u * n:
            ret[0] += 1
        ret[1] += 1
    return ret[0] / float(ret[1]), C

def test2():
    u = 4
    c = 3
    n = 7

    # ep = .2
    times = 10000

    ret = []
    step = 100
    ep = 0
    for i in range(0, step + 1):
        ep = i / step
        test1 = test_failure2(n, u, c, ep)
        test2, C = test_failure_random2(n, u, c, ep, times)
        # if test < ep:
        #     print(ep, test)
        ret.append([ep, test1, test2])
        ep += step
        print(i, "/", step, "\t", test1, "\t", test2, "\t", C)
    # print(ret)
    return ret

if __name__ == "__main__":
    test2()
