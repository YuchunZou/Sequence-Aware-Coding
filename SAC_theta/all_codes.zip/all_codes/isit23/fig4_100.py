import csv

I = []
R = []
R2 = []
C = []

with open('fig4.txt', newline = '') as data:
    D = csv.reader(data, delimiter='\t')
    for l in D:
        x = l[0].split()
        I.append(float(x[0]) / float(x[2]))
        R.append(float(x[3]))
        R2.append(float(x[4]))
        C.append(float(x[5]))

import numpy as np
print(np.mean([np.abs(I[i] - R[i]) for i in range(len(I))]))
print(np.mean([np.abs(I[i] - R2[i]) for i in range(len(I))]))

import matplotlib.pyplot as plt
import matplotlib
import numpy as np

plt.style.use('default')
font = {'family' : 'Helvetica', 'weight' : 'normal', 'size'   : 16, }
lines = {'linewidth' : 2, 'color' : 'black'}
axes = {'edgecolor' : 'black', 'grid' : False, 'titlesize' : 'medium'}
grid = {'alpha' : 0.1, 'color' : 'black'}
figure = {'titlesize' : 32, 'autolayout' : True, 'figsize' : "4, 12"}

matplotlib.rc('font', **font)
matplotlib.rc('lines', **lines)
matplotlib.rc('axes', **axes)
matplotlib.rc('grid', **grid)
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['text.usetex'] = True

COLOR2 = "#69b3a2"
COLOR1 = "#3399e6"

fig, (ax1, ax2) = plt.subplots(1, 2)
fig.set_size_inches(6, 3)
ax1.plot(I, I, '--', color='gray', alpha=0.4)
# ax1.plot(I, R, color=COLOR1)
ax1.plot(I, R2, color=COLOR1)
ax1.set_xlim([0, 1])
ax1.set_ylim([0, 1])
ax1.set_ylabel("actual recoverability")
ax1.tick_params(axis="y")
ax1.set_xlabel(r"$\theta$")
ax1.grid("on")
# ax1.legend()

ax2.plot(I, [i * 20 for i in I], '--', color='gray', alpha=0.4)
ax2.plot(I, C, color=COLOR2)
ax2.set_xlim([0, 1])
ax2.set_ylim([0, 20])
ax2.set_ylabel("complexity")
ax2.tick_params(axis="y")
ax2.set_xlabel(r"$\theta$")
ax2.grid("on")
# ax2.legend()

plt.tight_layout(pad=0.1)
plt.show()
# plt.savefig('./fig3.pdf', format='pdf', facecolor="white")



