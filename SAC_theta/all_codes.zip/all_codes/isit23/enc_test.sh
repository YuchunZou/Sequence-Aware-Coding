#!/bin/bash
echo " please enter code(static/stochastic)"
read code 
for eps in 0.25 0.5 0.75 1
do
  echo "epsilon value is $eps "
  python3 enc.py $code 4000 4000 4000 100 20 10 4 $eps 
done
